$('.up-work').click(function(e) {
	$('html, body').animate({scrollTop:0}, 500);
});