$(function(){


if($('.cart-mask').length){
        $('.cart-mask').mask('9999  9999  9999  9999',{placeholder:" "});
    };



});
